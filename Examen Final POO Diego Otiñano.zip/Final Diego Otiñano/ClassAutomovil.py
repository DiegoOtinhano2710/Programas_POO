from ClassVehiculo import vehiculo
class automovil(vehiculo):
    __pasajeros_max:int
    __cant_pasajeros:int
    def __init__(self,mat,mod,cos,cant,pasmax,pasreal):
        super().__init__(mat,mod,cos,cant)
        self.__pasajeros_max=pasmax
        self.__cant_pasajeros=pasreal
    
    def getmatr(self):
        return super().getmatr()
    def getmod(self):
        return super().getmod()
    def getcosto(self):
        return super().getcosto()
    def getdias(self):
        return super().getdias()
    def getmax(self):
        return self.__pasajeros_max
    def getcant(self):
        return self.__cant_pasajeros
    def mostrar(self):
        print(f'''Matrícula del vehículo: {self.getmatr()}
Modelo: {self.getmod()}
Costo por kilómetro: {self.getcosto()}
Cantidad de dias de alquiler: {self.getdias()}
Número maximo de pasajeros: {self.__pasajeros_max}
Cantidad real de pasajeros: {self.__cant_pasajeros}\n''')
        
    def costo(self):
        return self.getdias() * self.getcosto()+ 5000 * self.__cant_pasajeros