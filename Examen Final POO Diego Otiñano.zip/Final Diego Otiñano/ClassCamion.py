from ClassVehiculo import vehiculo
class camion(vehiculo):
    __capacidad_max:float
    __carga_real:float
    __lista_rutas:list
    def __init__(self,mat,mod,cos,cant,capm,carga):
        super().__init__(mat,mod,cos,cant)
        self.__capacidad_max=capm
        self.__carga_real=carga
        self.__lista_rutas=[]
    
    def agregar_ruta(self,ruta):
        self.__lista_rutas.append(ruta)
    def getmatr(self):
        return super().getmatr()
    def getmod(self):
        return super().getmod()
    def getcosto(self):
        return super().getcosto()
    def getdias(self):
        return super().getdias()
    def getcap(self):
        return self.__capacidad_max
    def getcarga(self):
        return self.__carga_real
    def mostrar(self):
        print(f'''Matrícula del vehículo: {self.getmatr()}
Modelo: {self.getmod()}
Costo por kilómetro: {self.getcosto()}
Cantidad de dias de alquiler: {self.getdias()}
Capacidad máxima de carga: {self.__capacidad_max}
Carga real: {self.__carga_real}
Lista de rutas:''')
        i=0
        while i < len(self.__lista_rutas):
            print(self.__lista_rutas[i].getcod())
            i+=1
    
    def costo(self):
        total=0
        if self.__carga_real > 4500:
            total = (self.getdias() * self.getcosto()) + (0.05 * self.getcosto())
        else:
            total = (self.getdias()*self.getcosto()) + (0.02 * self.getcosto())
        return total