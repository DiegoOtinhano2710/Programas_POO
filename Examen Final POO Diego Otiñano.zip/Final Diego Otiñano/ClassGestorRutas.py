from ClassRuta import ruta
import csv
class gestor_ruta:
    __lista_rutas:list
    def __init__(self):
        self.__lista_rutas=[]
    def agregar_rutas(self,nuevo):
        self.__lista_rutas.append(nuevo)
    
    def leerdatos(self):
        try:
            archivo=open('Rutas.csv')
            reader=csv.reader(archivo,delimiter=';')
            band=True
            for fila in reader:
                if band:
                    band=False
                else:
                    if fila[3] == 'FALSO':
                        nueva_ruta=ruta(fila[0],fila[1],fila[2],False)
                        self.agregar_rutas(nueva_ruta)
            archivo.close()
        except FileNotFoundError:
            ("Error al leer el archivo")

    def buscar_rutas(self):
                try:
                    i=0
                    cod=int(input("Ingrese el código de la ruta que desea asignarle al camión: "))
                    while i < len(self.__lista_rutas) and self.__lista_rutas[i].getcod() != cod:
                        i = i+1
                    if self.__lista_rutas[i].getcod() != cod:
                        raise IndexError
                    else:
                        if self.__lista_rutas[i].getasig() == False:
                            self.__lista_rutas[i].setasig()
                            print("¡Ruta asignada con éxito!")
                            return self.__lista_rutas[i]
                        else:
                            raise IOError
                except IndexError:
                    print("No existe la ruta ingresada")
                except IOError:
                    print("La ruta ya está asignada a un camión")
