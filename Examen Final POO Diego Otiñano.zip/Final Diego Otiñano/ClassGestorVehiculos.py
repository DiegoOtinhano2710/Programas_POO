from ClassAutomovil import automovil
from ClassCamion import camion
import csv
class gestor_vehiculo:
    __lista_vehiculos:list
    def __init__(self):
        self.__lista_vehiculos=[]

    def agregar_vehiculo(self,gr):
        tipo=input("Seleccione el tipo de vehículo: a) Automovil  -  c) Camión    ")
        matricula=input("Ingresar matrícula del vehiculo: ")
        modelo=input("Ingresar modelo del vehículo: ")
        costo=float(input("Ingresar costo por kilómetro: "))
        cant_dias=int(input("Ingresar cantidad de días de alquiler: "))
        if tipo.lower() == 'a':
            max=int(input("Ingresar cantidad máxima de pasajeros: "))
            cant_real=int(input("Ingresar la cantidad real de pasajeros: "))
            nuevoauto=automovil(matricula,modelo,costo,cant_dias,max,cant_real)
            self.__lista_vehiculos.append(nuevoauto)
            print("¡Automovil registrado correctamente!\n")
        elif tipo.lower() == 'c':
            cap_max=float(input("Ingresar capacidad máxima de carga: "))
            carga_real=float(input("Ingresar la carga real del camión: "))
            nuevocamion=camion(matricula,modelo,costo,cant_dias,cap_max,carga_real)
            respuesta='si'
            while respuesta.lower() != 'no':
                ruta = gr.buscar_rutas()
                if ruta != None:
                    nuevocamion.agregar_ruta(ruta)
                respuesta=input("¿Desea asignarle otra ruta?  si/no    --> ")
                while respuesta.lower() != 'si' and respuesta.lower() != 'no':
                    respuesta=input("Seleccione solo las respuestas si o no: ")
            self.__lista_vehiculos.append(nuevocamion)
        

    def buscar(self):
        try:
            i=0
            matr=input("Ingresar matrícula del vehículo: ")
            while i < len(self.__lista_vehiculos) and self.__lista_vehiculos[i].getmatr() != matr:
                i+=1
            if i == len(self.__lista_vehiculos):
                raise IndexError
            else:
                self.__lista_vehiculos[i].mostrar()
        except IndexError:
            print("El vehículo no se encontró")
    
    def costo(self):
        for vehiculo in self.__lista_vehiculos:
            print(f'''Matrícula: {vehiculo.getmatr()}
Modelo: {vehiculo.getmod()}
Costo de alquiler: {vehiculo.costo()}\n''')