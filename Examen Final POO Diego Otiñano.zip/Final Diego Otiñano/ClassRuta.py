class ruta:
    __cod:int
    __destino:str
    __distancia:float
    __ruta_asignada:bool
    def __init__(self,cod,des,dis,ruta):
        self.__cod=int(cod)
        self.__destino=des
        self.__distancia=dis
        self.__ruta_asignada=ruta
    
    def getcod(self):
        return self.__cod
    def getasig(self):
        return self.__ruta_asignada
    def setasig(self):
        self.__ruta_asignada = True