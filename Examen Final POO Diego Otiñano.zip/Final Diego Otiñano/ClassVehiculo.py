class vehiculo:
    __matricula:str
    __modelo:str
    __costoKM:float
    __cantDeDias:int
    def __init__(self,mat,mod,cos,cant):
        self.__matricula=mat
        self.__modelo=mod
        self.__costoKM=cos
        self.__cantDeDias=cant
    
    def getmatr(self):
        return self.__matricula
    def getmod(self):
        return self.__modelo
    def getcosto(self):
        return self.__costoKM
    def getdias(self):
        return self.__cantDeDias    
    @classmethod
    def costo(cls):
        pass