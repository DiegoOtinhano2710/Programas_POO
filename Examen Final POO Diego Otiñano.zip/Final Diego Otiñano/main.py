from ClassGestorRutas import gestor_ruta
from ClassGestorVehiculos import gestor_vehiculo
class main:

    def menu():
        GV=gestor_vehiculo()
        GR=gestor_ruta()
        GR.leerdatos()
        op=input('''Seleccione una opción:
                 a) Agregar nuevo vehículo
                 b) Buscar vehículo
                 c) Datos de vehículo
                 z) salir
                 --->  ''')
        while op.lower()!='z':
            if op.lower()=='a':
                GV.agregar_vehiculo(GR)
            elif op.lower()=='b':
                GV.buscar()
            elif op.lower()=='c':
                GV.costo()
            else:
                print("Ingrese una opción correcta")
            op=input('''Seleccione una opción:
                 a) Agregar nuevo vehículo
                 b) Buscar vehículo
                 c) Datos de vehículo
                 z) salir
                 --->  ''')

    if __name__=='__main__':
        menu()