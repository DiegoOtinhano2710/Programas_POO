import abc
from abc import ABC
class planes:
    __nombre_comp:str
    __duracion_plan:int
    __cobertura_geo:str
    __precio_base:float

    def __init__(self,nom,dur,cob,precio):
        self.__nombre_comp=nom
        self.__duracion_plan=int(dur)
        self.__cobertura_geo=cob
        self.__precio_base=float(precio)
    
    def getdur(self):
        return self.__duracion_plan
    
    def getcob(self):
        return self.__cobertura_geo
    def getnom(self):
        return self.__nombre_comp
    def getpreciobase(self):
        return self.__precio_base
    @abc.abstractmethod
    def getimporte(self):
        pass

    def datos(self, tipo):
        nom=self.getnom()
        der=self.getdur()
        cob=self.getcob()
        importefinal=self.getimporte()
        print('Tipo de plan: {} Nombre de la compañía: {} Duración del plan: {} Cobertura geográfica: {} Importe final: {}'.format(tipo,nom,der,cob,importefinal))