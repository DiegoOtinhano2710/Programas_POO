from gestor import gestorplanes

def menu():
    gp=gestorplanes()
    gp.leerdatos()
    op=input('''Seleccionar una opción:
             1) Tipo de plan
             2) Planes por cobertura geográfica
             3) Cantidad de canales internacionales
             4) Datos de los planes
             5) Salir
             --> ''')
    while op!='5':
        if op=='1':
            gp.tipoplan()
        elif op=='2':
            gp.planesxcob()
        elif op=='3':
            gp.canalesinter()
        elif op=='4':
            gp.datosplanes()
        op=input('seleccionar una opción: ')



if __name__=='__main__':
    menu()