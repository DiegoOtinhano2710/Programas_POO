class mama:
    __dni:int
    __edad:int
    __apynom:str
    

    def __init__(self,dni,edad,ayn):
        self.__dni=dni
        self.__edad=edad
        self.__apynom=ayn
  
    def __str__(self):
        return f'''Nombre y Apellido: {self.__apynom}
DNI: {self.__dni}
Edad: {self.__edad}'''
    def getdni(self):
        return self.__dni
    def getnya(self):
        return self.__apynom
    def getedad(self):
        return self.__edad