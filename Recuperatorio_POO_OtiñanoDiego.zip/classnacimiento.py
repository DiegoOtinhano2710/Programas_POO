class nacimiento:
    __dnimama:int
    __tipoparto:str
    __fecha:str
    __hora:str
    __pesokg:float
    __altura:float

    def __init__(self,xdni,tipo,fecha,hora,peso,altura):
        self.__dnimama=xdni
        self.__tipoparto=tipo
        self.__fecha=fecha
        self.__hora=hora
        self.__pesokg=peso
        self.__altura=altura

    def getdnim(self):
        return self.__dnimama
    def gettipo(self):
        return self.__tipoparto
    def getpeso(self):
        return self.__pesokg
    def getaltura(self):
        return self.__altura
    def getfecha(self):
        return self.__fecha
    def __eq__(self,otro):
        return self.__dnimama == otro.getdnim() and self.__fecha == otro.getfecha()
