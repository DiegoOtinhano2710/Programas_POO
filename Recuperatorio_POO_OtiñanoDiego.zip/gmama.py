from classmama import mama
import numpy as np
import csv
from classnacimiento import nacimiento
class gestormama:
    __dimension:int
    __inc:int
    __cantidad:int
    __listamama=np.array

    def __init__(self):
        self.__listamama=np.empty([], dtype=mama)
        self.__dimension=0
        self.__inc=1
        self.__cantidad=0
    
    def agregar(self,mama):
        if self.__dimension == self.__cantidad:
            self.__dimension+=self.__inc
            self.__listamama.resize(self.__dimension)
        self.__listamama[self.__cantidad]=mama
        self.__cantidad+=1

    def leerdatos(self):
        band=True
        archivo=open('Mamas.csv')
        reader=csv.reader(archivo, delimiter=';')
        for fila in reader:
            if band:
                band=False
            else:
                xdni=int(fila[0])
                xedad=int(fila[1])
                xnya=fila[2]
                nuevamama=mama(xdni,xedad,xnya)
                self.agregar(nuevamama)
        archivo.close()
    

    def buscar(self,gn):
        xdni=int(input("Ingresar DNI de la mamá: "))
        i=0
        band=False
        while i<len(self.__listamama) and band==False:
            if xdni==self.__listamama[i].getdni():
                nya=self.__listamama[i].getnya()
                edad=self.__listamama[i].getedad()
                print (f'''
                       Apellido y nombre: {nya}
                       Edad: {edad}''')
                gn.buscar(xdni)
                band=True
            else:
                i+=1
    
    def datos(self,dni):
        i=0
        band=False
        while i<len(self.__listamama) and band ==False:
            if dni==self.__listamama[i].getdni():
                print(self.__listamama[i])
                band=True
            else:
                i+=1