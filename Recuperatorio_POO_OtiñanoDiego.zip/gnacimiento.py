from classnacimiento import nacimiento
import csv
from classmama import mama
class gestornacimiento:
    __listanac:list

    def __init__(self):
        self.__listanac=[]
    
    def agregar(self,nacimiento):
        self.__listanac.append(nacimiento)
    
    def leerdatos(self):
        band=True
        archivo=open('Nacimientos.csv')
        reader=csv.reader(archivo, delimiter=';')
        for fila in reader:
            if band:
                band=False
            else:
                xdni=int(fila[0])
                xtipo=fila[1]
                xfecha=fila[2]
                xhora=fila[3]
                xpeso=fila[4]
                xaltura=fila[5]
                nuevonac=nacimiento(xdni,xtipo,xfecha,xhora,xpeso,xaltura)
                self.agregar(nuevonac)
        archivo.close()
    
    def buscar(self,xdni):
        i=0
        while i<len(self.__listanac):
            if xdni==self.__listanac[i].getdnim():
                tipo=self.__listanac[i].gettipo()
                peso=self.__listanac[i].getpeso()
                altura=self.__listanac[i].getaltura()
                print(f'''
                      Tipo de parto: {tipo}
                      Peso        Altura
                      {peso}        {altura}''')
            i+=1
    
    def multiples(self,gm):
        i=0
        while i<len(self.__listanac):
            j=i+1
            while j<len(self.__listanac):
                if self.__listanac[i]==self.__listanac[j]:
                    dni=self.__listanac[i].getdnim()
                    gm.datos(dni)
                j+=1
            i+=1