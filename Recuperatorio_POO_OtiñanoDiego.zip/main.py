from gmama import gestormama
from gnacimiento import gestornacimiento
def menu():
    gm=gestormama()
    gn=gestornacimiento()
    gm.leerdatos()
    gn.leerdatos()
    opcion=input('''seleccionar opcion: 
                 a) Mostrar informacion del bebé
                 b) Mamás con multiples partos
                 c) Salir del menú
                 --> ''')
    while opcion != 'c':
        if opcion=='a':
            gm.buscar(gn)
        elif opcion=='b':
            gn.multiples(gm)
        opcion=input("seleccionar opcion: ")

if __name__=='__main__':
    menu()